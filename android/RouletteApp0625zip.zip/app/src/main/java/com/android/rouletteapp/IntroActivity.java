package com.android.rouletteapp;

import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class IntroActivity extends AppCompatActivity {
        private Button insert_btn1;
        private int insert_cnt;
        private ArrayList in_txt;
        private LinearLayout linelayout1;
        private TextView view1;
        private TextView view2;
        private TextView view3;
        private TextView view4;
        private TextView view5;
        private TextView view6;
        private TextView view7;
        private TextView view8;

        private EditText edit1;
    private static final float FONT_SIZE = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        insert_btn1 = (Button) findViewById(R.id.insert_btn1);
        //부모 뷰
        linelayout1 = (LinearLayout) findViewById(R.id.linelayout1);

        //
        edit1 = (EditText)findViewById(R.id.edit1);
        //
        in_txt = new ArrayList();

        insert_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                //TextView 생성
                if(view1  ==  null){
                    TextView view1 = new TextView(IntroActivity.this);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    lp.gravity = Gravity.CENTER;
                    view1.setLayoutParams(lp);
                    view1.setText(edit1.getText().toString());
                    view1.setTextSize(FONT_SIZE);
                    view1.setTextColor(Color.BLACK);
                    linelayout1.addView(view1);
                    in_txt.add(view1);
                }

                insert_cnt ++;

            }
        });


        //
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });



    }

}
